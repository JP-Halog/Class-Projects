/** 
 *Prints my full name and my goals in life.
 *
 *Proj_01
 *@author John Peter Halog
 *@version 08-28-19
 */
public class MyLifeGoals
{
/**
 *Prints name and life goals.
 *@param args Command line arguements - not used.
 */
   public static void main(String[]args)
   {
      System.out.println("John Peter Halog");
      System.out.println();
      System.out.println("My short-term life goals consist of having all As,"
         + " becoming a selfless person, and getting closer to God."
         + " I have been recently re-evaluating my past to see"
         + " how I can move forward in my life, while staying in the present.");
      System.out.println("My mid-term life goals consist of graduating college,"
         + " finding a good stressless job,"
         + " finding true love with someone and living happily ever after.");
      System.out.println("My long term life goal consists of only one thing:"
         + " I want to live a virtuous life grounded in charity."
         + " A virtuous life can be lived in lots of ways, but"
         + " I define it as a life that is full of meaning and kindness.");
   }
}