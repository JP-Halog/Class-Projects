/**
 *Prints a Letter J in a super duper complicated way with the word Java.
 *
 *Proj_1
 *@author John Peter Halog - COMP1210 - 06
 *@version 08-28-19
 */
public class JLetter
{
/**
 *Creates an over complicated J.
 *@param args Command line arguements - not used.
 */
   public static void main(String[]args)
   {
      System.out.println("JAVAJAVAJAVA");
      System.out.println("JAVAJAVAJAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("J     JAVA");
      System.out.println("JA    JAVA");
      System.out.println(" JAVAJAVA");
      System.out.println("  JAVAJA");
   }
}