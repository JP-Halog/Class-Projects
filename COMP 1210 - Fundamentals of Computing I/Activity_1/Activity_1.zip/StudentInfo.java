/**
 * Simple program giving student info.
 * 
 * Activity 1
 * @author John Peter Halog - COMP 1210 - 06
 * @version 08-26-19
 */
public class StudentInfo
{
/**
 * Prints Hello World one time.
 * @param args Comand line arguements - not used.
 */
   public static void main(String[] args)
   {
      System.out.println("Name: John Peter Halog");
      System.out.println("Previous Computer Courses:");
      System.out.println("   None");
   }
}